# Pedidos de Funcionalidades

Ordenados por facilidade de implementação (mais fácil para mais difícil):

- [ ] Efeitos como reverb, delay e bitcrushing
- [ ] EQ Personalizável: Permitir que usuários alterem o número de bandas do EQ e seu alcance (-30 a 30), com interface de arrastar para ajustar similar ao editor de velocidade do FL Studio

[ ] Suporte a SoundCloud: Integrar SoundCloud através do SoundCloak
