// functions/track/t/[id].js - Re-export handler from parent for /track/t/:id routes
export { onRequest } from '../[id].js';
