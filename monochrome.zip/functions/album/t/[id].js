// functions/album/t/[id].js - Re-export handler from parent for /album/t/:id routes
export { onRequest } from '../[id].js';
