// functions/artist/t/[id].js - Re-export handler from parent for /artist/t/:id routes
export { onRequest } from '../[id].js';
