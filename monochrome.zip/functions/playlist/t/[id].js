// functions/playlist/t/[id].js - Re-export handler from parent for /playlist/t/:id routes
export { onRequest } from '../[id].js';
